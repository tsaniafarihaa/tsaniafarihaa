#include "OLIMPIADE.H"

int main(){
    list_negara ln;
    adr_negara n;
    string negara;
    createlist_negara(ln);

    list_cabor lc;
    adr_cabor c;
    string cabor;
    createlist_cabor(lc);

    list_relasi lr;
    adr_relasi r;
    createlist_relasi(lr);

    cout << "===== TUGAS BESAR TSANIA & DAFFA =====" << endl;
    cout << endl;
    cout << "===== WELCOME TO OLIMPIADE 2023 =====" << endl;

    int pilihan = menu();

    while(pilihan != 0){
    	cout << endl;
        switch(pilihan){
        case 1 :
            cout << "Masukkan nama cabang olah raga: ";
            cin >> cabor;

            c = findelemcabor(lc, cabor);
            cout << endl;
            if(c == NULL){
	            createelm_cabor(cabor, c);
	            insert_cabor(lc, c);

	            cout << "Berhasil Menambahkan Cabang Olah Raga " << cabor << endl;
			}else{
				cout << "Gagal Menambahkan Cabang Olah Raga " << cabor << ". Cabang Olah Raga Tersebut Sudah Terdaftar Sebelumnya" << endl;
			}

            break;
        case 2 :
            cout << "Masukkan nama negara: ";
            cin >> negara;

            n = findelemnegara(ln, negara);
            cout << endl;
            if(n == NULL){
	            createelm_negara(negara, n);
	            insert_negara(ln, n);

	            cout << "Berhasil Menambahkan Negara " << negara << endl;
			}else{
				cout << "Gagal Menambahkan Negara " << negara << ". Negara Tersebut Sudah Terdaftar Sebelumnya" << endl;
			}

            break;
        case 3 :
        	cout << "Masukkan nama cabang olahraga: ";
            cin >> cabor;

            c = findelemcabor(lc, cabor);
            cout << endl;
            if(c != NULL){
            	cout << "Cabang Olah Raga " << info(c) << " Ditemukan!" << endl;
			}else{
				cout << "Cabang Olah Raga " << cabor << " Tidak Ditemukan" << endl;
			}

            break;
        case 4 :
        	cout << "Masukkan nama cabang olah raga: ";
            cin >> cabor;
            cout << endl;
            cout << "Masukkan nama negara: ";
            cin >> negara;
            c = findelemcabor(lc, cabor);
            n = findelemnegara(ln, negara);
            r = findelemrelasi(lr, c, n);

            cout << endl;
            if(c != NULL && n != NULL && r == NULL){
	            createelm_relasi(r,c,n);
	            insert_relasi(lr,r);

	            cout << "Berhasil Menambahkan Relasi Antara Cabang Olah Raga " << cabor << " dengan Negara " << negara << endl;
			}else if(c == NULL && n == NULL){
				cout << "Gagal Menambahkan Relasi, Cabang Olah Raga " << cabor << " dan Negara " << negara << " Tidak Terdaftar" << endl;
			}else if(c == NULL){
				cout << "Gagal Menambahkan Relasi, Cabang Olah Raga " << cabor << " Tidak Terdaftar" << endl;
			}else if(n == NULL){
				cout << "Gagal Menambahkan Relasi, Negara " << negara << " Tidak Terdaftar" << endl;
			}else{
				cout << "Gagal Menambahkan Relasi, Relasi Sudah Terdaftar" << endl;
			}

            break;
        case 5 :
        	if(!isCaborEmpty(lc)){
	        	cout << "Masukkan nama cabang olah raga: ";
	            cin >> cabor;

	            cout << endl;
	            findnegarafromcabor(lr, cabor);
			}else{
				cout << "Data Negara Masih Kosong!" << endl;
			}

            break;
        case 6 :
        	if(!isCaborEmpty(lc)){
	        	cout << "Masukkan nama cabang olah raga: ";
	            cin >> cabor;

	            cout << endl;
	            delete_cabor(lc, lr, cabor);
			}else{
				cout << "Data Cabang Olah Raga Masih Kosong!" << endl;
			}

			break;
        case 7 :
            if(!isRelasiEmpty(lr)){
	        	cout << "Masukkan nama cabang olah raga: ";
	            cin >> cabor;

	            cout << endl;
	            delete_negarafromcabor(lr, cabor);
			}else{
				cout << "Data Masih Kosong!" << endl;
			}

			break;
		case 8 :
			if(!isRelasiEmpty(lr)){
	        	showallnegarafromallcabor(lc, lr);
			}else{
				cout << "Cabang Olah Raga Masih Belum Diikuti Oleh Satupun Negara" << endl;
			}

			break;
		case 9 :
			if(!isRelasiEmpty(lr)){
	        	cout << "Masukkan nama cabang olah raga: ";
	            cin >> cabor;

	            cout << endl;
	            c = findelemcabor(lc, cabor);
	            cout << "Jumlah Negara yang Mengikuti Cabang Olah Raga " << cabor << " Sebanyak " << getsumnegarafromcabor(lr, cabor) << endl;
			}else{
				cout << "Cabang Olah Raga Masih Belum Diikuti Oleh Satupun Negara" << endl;
			}

			break;
		case 10 :
			if(!isRelasiEmpty(lr)){
	        	findminmax(lr, lc);
			}else{
				cout << "Cabang Olah Raga Masih Belum Diikuti Oleh Satupun Negara" << endl;
			}

			break;
        }

        if(pilihan != 0){
        	cout << endl;
        	system("pause");
        	system("cls");
		}

        cout << "SELAMAT DATANG DI APLIKASI OLIMPIADE" << endl;
        pilihan = menu();
	}
	cout << endl << "Anda telah keluar dari program" << endl;

	return 0;
}
