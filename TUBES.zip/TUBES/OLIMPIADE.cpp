#include "OLIMPIADE.h"

int menu(){
    cout << endl << "===== Menu =====" << endl <<
    "1. Menambah data cabang olah raga" << endl <<
    "2. Menambah data negara" << endl <<
    "3. Mencari data cabang olah raga" << endl <<
    "4. Menambah data relasi" << endl <<
    "5. Mencari data negara yang mengikuti olah raga tertentu" << endl <<
    "6. Menghapus data olah raga beserta relasinya" << endl <<
    "7. Menghapus data negara pada cabang olah raga tertentu" << endl <<
    "8. Menampilkan data olah raga beserta negara yang mengikuti" << endl <<
    "9. Menghitung banyaknya negara dalam satu cabang olah raga tertentu" << endl <<
    "10.Menampilkan data cabang olah raga paling banyak dan paling dikit diikuti" << endl <<
	"0. Exit" << endl << endl;

    int input;
    cout << "Masukkan menu: ";
    cin >> input;

    return input;
}

void createlist_negara(list_negara &ln){
    first(ln) = NULL;
}

void createelm_negara(string x, adr_negara &n){
    n = new elm_negara;
    info(n) = x;
    next(n) = NULL;
}

bool isNegaraEmpty(list_negara ln){
	if(first(ln) == NULL){
		return true;
	}
	return false;
}

void insert_negara(list_negara &ln, adr_negara n){
    if(first(ln) == NULL){
        first(ln) = n;
    }else{
        adr_negara q = first(ln);
        while(next(q) != NULL){
            q = next(q);
        }
        next(q) = n;
    }
}

void show_negara(list_negara ln){
    if(first(ln) == NULL){
        cout << "List kosong" << endl;
    }else{
        adr_negara q = first(ln);
        cout << "List Negara: ";
        while(next(q) != NULL){
            cout << info(q) << ", ";
            q = next(q);
        }
        cout << info(q) << endl;
    }
}

adr_negara findelemnegara(list_negara ln, string x){
    adr_negara n = first(ln);
    while(n != NULL){
        if(info(n) == x){
            return n;
        }
        n = next(n);
    }
    return NULL;
}

void createlist_cabor(list_cabor &lc){
    first(lc) = NULL;
}

void createelm_cabor(string x, adr_cabor &c){
    c = new elm_cabor;
    info(c) = x;
    next(c) = NULL;
    prev(c) = NULL;
}

bool isCaborEmpty(list_cabor lc){
	if(first(lc) == NULL){
		return true;
	}
	return false;
}

void insert_cabor(list_cabor &lc, adr_cabor c){
    if(first(lc) == NULL){
        first(lc) = c;
    }else{
        adr_cabor q = first(lc);
        while(next(q) != NULL){
            q = next(q);
        }
        next(q) = c;
        prev(c) = q;
    }

}
void show_cabor(list_cabor lc){
    if(first(lc) == NULL){
        cout << "List kosong" << endl;
    }else{
        adr_cabor q = first(lc);
        cout << "List orang tua: ";
        while(q != NULL){
            cout << info(q) << ", ";
            q = next(q);
        }
    }
}

adr_cabor findelemcabor(list_cabor lc, string x){
    adr_cabor c = first(lc);
    while(c != NULL){
        if(info(c) == x){
            return c;
        }
        c = next(c);
    }
    return NULL;
}

void createlist_relasi(list_relasi &lr){
    first(lr) = NULL;
}

void createelm_relasi(adr_relasi &r, adr_cabor c, adr_negara n){
    r = new elm_relasi;
    nextNegara(r) = n;
    nextCabor(r) = c;
    next(r) = NULL;
}

bool isRelasiEmpty(list_relasi lr){
	if(first(lr) == NULL){
		return true;
	}
	return false;
}

void insert_relasi(list_relasi &lr, adr_relasi r){
    adr_relasi rr = first(lr);
    if(first(lr) == NULL){
        first(lr) = r;
        next(first(lr)) = first(lr);
        prev(first(lr)) = first(lr);
    }else{
        adr_relasi rr = first(lr);
        while(next(rr) != first(lr)){
            rr = next(rr);
        }
        next(rr) = r;
        prev(r) = rr;

        next(r) = first(lr);
        prev(first(lr)) = r;
    }
}

void show_relasi(list_relasi lr){
    adr_relasi r = first(lr);
    while(next(r) != first(lr)){
        cout << info(nextCabor(r)) << " -> " << info(nextNegara(r)) << endl;
        r = next(r);
    }
    cout << info(nextCabor(r)) << " -> " << info(nextNegara(r)) << endl;
}

adr_relasi findelemrelasi(list_relasi lr, adr_cabor c, adr_negara n){
	adr_relasi r = first(lr);

	if(r == NULL){
		return NULL;
	}

    while(next(r) != first(lr)){
        if(nextCabor(r) == c && nextNegara(r) == n){
        	return r;
		}
        r = next(r);
    }
    if(nextCabor(r) == c && nextNegara(r) == n){
        return r;
	}
	return NULL;
}

void findnegarafromcabor(list_relasi lr, string x){
	adr_relasi r = first(lr);
	int count = 0;
	if(r != NULL){
		while(next(r) != first(lr)){
			if(info(nextCabor(r)) == x){
				count += 1;
				if(count == 1){
					cout << "Data Negara yang Mengikuti Cabang Olah Raga " << x << " :" << endl;
				}
				cout << count << ". " << info(nextNegara(r)) << endl;
			}
			r = next(r);
		}

		if(info(nextCabor(r)) == x){
			count += 1;
			if(count == 1){
				cout << "Data Negara yang Mengikuti Cabang Olah Raga " << x << " :" << endl;
			}
			cout << count << ". " << info(nextNegara(r)) << endl;
		}
	}

	if(count == 0){
		cout << "Tidak Ada Data Negara yang Mengikuti Olah Raga " << x << endl;
	}
}

void showallnegarafromallcabor(list_cabor lc, list_relasi lr){
	adr_cabor t = first(lc);

	while(t != NULL){
		cout << "Cabang Olah Raga " << info(t) << " :" << endl;
		findnegarafromcabor(lr, info(t));
		cout << endl;
		t = next(t);
	}
}

int getsumnegarafromcabor(list_relasi lr, string x){
    int count = 0;
    adr_relasi r = first(lr);
    while(next(r) != first(lr)){
        if(info(nextCabor(r)) == x){
            if(nextNegara(r) != NULL){
                count += 1;
            }
        }
        r = next(r);
    }
    if(info(nextCabor(r)) == x){
        if(nextNegara(r) != NULL){
            count += 1;
        }
    }

    return count;
}

void findminmax(list_relasi lr, list_cabor lc){
	int max = INT_MIN;
    int min = INT_MAX;
    int count;
	string cabor_min, cabor_max;
	adr_cabor c = first(lc);

	while(c != NULL){
		count = getsumnegarafromcabor(lr, info(c));

		if(count > max){
			max = count;
			cabor_max = info(c);
		}

		if(count < min){
			min = count;
			cabor_min = info(c);
		}

		c = next(c);
	}

	cout << "Cabang Olah Raga Paling Banyak Diikuti adalah " << cabor_max << " dengan " << max << " Negara yang Mengikutinya" << endl;
	cout << "Cabang Olah Raga Paling Sedikit Diikuti adalah " << cabor_min << " dengan " << min << " Negara yang Mengikutinya" << endl;
}


adr_cabor findcaborfromnegara(list_relasi lr, string x){
    adr_relasi r = first(lr);
    while(r != NULL){
        if(info(nextNegara(r)) == x){
            return nextCabor(r);
        }
        r = next(r);
    }
    return NULL;
}

void delete_cabor(list_cabor &lc, list_relasi &lr, string x){
    adr_relasi r = first(lr);
    adr_relasi pr = NULL;
    adr_relasi pd = NULL;

    if(r != NULL){
	    //Delete all relation cabang olah raga
		while(next(r) != first(lr)){
			if(info(nextCabor(r)) == x){
				pd = r;
				if(pr == NULL){
					next(prev(first(lr))) = next(r);
					prev(first(lr)) = prev(r);
					first(lr) = next(r);

					pr = NULL;
					r = first(lr);
				}else{
					next(pr) = next(r);
					prev(next(r)) = pr;

					r = next(pr);
				}
				delete pd;
			}else{
				pr = r;
		    	r = next(r);
			}
		}
		if(info(nextCabor(r)) == x){
			pd = r;
			if(first(lr) == r){
				first(lr) = NULL;
			}else{
				next(pr) = next(r);
				prev(first(lr)) = pr;
			}
			delete pd;
		}
	}

	//Delete cabang olah raga
	adr_cabor c = first(lc);
	adr_cabor pc = NULL;
	adr_cabor caborDel = NULL;
	bool found = false;

	while(c != NULL){
		if(info(c) == x){
			caborDel = c;
			if(pc == NULL){
				first(lc) = next(c);
				if(first(lc) != NULL){
					prev(first(lc)) = NULL;
				}
			}else{
				next(pc) = next(c);
				if(next(pc) != NULL){
					prev(next(c)) = pc;
				}
			}
			found = true;
			delete caborDel;
			break;
		}else{
			pc = c;
			c = next(c);
		}
	}

	if(!found){
		cout << "Gagal Menghapus Data Cabang Olah Raga " << x << ". Karena Data Tidak Ditemukan" << endl;
	}else{
		cout << "Berhasil Menghapus Data Cabang Olah Raga " << x << " beserta Relasi Cabang Olah Raga Tersebut" << endl;
	}
}

void delete_negarafromcabor(list_relasi &lr, string x){
	adr_relasi r = first(lr);
    adr_relasi pr = NULL;
    adr_relasi pd = NULL;
    bool found = false;

    if(r != NULL){
	    //Delete all relation cabang olah raga
		while(next(r) != first(lr)){
			if(info(nextCabor(r)) == x){
				found = true;
				pd = r;
				if(pr == NULL){
					next(prev(first(lr))) = next(r);
					prev(first(lr)) = prev(r);
					first(lr) = next(r);

					pr = NULL;
					r = first(lr);
				}else{
					next(pr) = next(r);
					prev(next(r)) = pr;

					r = next(pr);
				}
				delete pd;
			}else{
				pr = r;
		    	r = next(r);
			}
		}
		if(info(nextCabor(r)) == x){
			pd = r;
			if(first(lr) == r){
				first(lr) = NULL;
			}else{
				next(pr) = next(r);
				prev(first(lr)) = pr;
			}
			delete pd;
		}
	}

	if(!found){
		cout << "Gagal Menghapus Data Negara Pada Cabang Olah Raga" << x << ". Karena Data Tidak Ditemukan" << endl;
	}else{
		cout << "Berhasil Menghapus Data Negara Pada Cabang Olah Raga " << x << endl;
	}
}
