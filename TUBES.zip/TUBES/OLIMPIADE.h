#ifndef OLIMPIADE_H_INCLUDED
#define OLIMPIADE_H_INCLUDED

#include <iostream>
#include <cstdlib>
#include <climits>
using namespace std;

#define info(p) (p)->info
#define next(p) (p)->next
#define prev(p) (p)->prev
#define first(l) ((l).first)
#define nextCabor(p) (p)->nextCabor
#define nextNegara(p) (p)->nextNegara

typedef struct elm_negara *adr_negara;
typedef struct elm_cabor *adr_cabor;
typedef struct elm_relasi *adr_relasi;

struct elm_negara{
    string info;
    adr_negara next;
};

struct elm_cabor{
    string info;
    adr_cabor next;
    adr_cabor prev;
};

struct elm_relasi{
    adr_cabor nextCabor;
    adr_negara nextNegara;
    adr_relasi next;
    adr_relasi prev;
};

struct list_negara{
    adr_negara first;
};

struct list_cabor{
    adr_cabor first;
};

struct list_relasi{
    adr_relasi first;
};

void createlist_negara(list_negara &ln);
void createelm_negara(string x, adr_negara &n);
bool isNegaraEmpty(list_negara ln);
void insert_negara(list_negara &ln, adr_negara n);
void show_negara(list_negara ln);
adr_negara findelemnegara(list_negara ln, string x);

void createlist_cabor(list_cabor &lc);
void createelm_cabor(string x, adr_cabor &c);
bool isCaborEmpty(list_cabor lc);
void insert_cabor(list_cabor &lc, adr_cabor c);
void show_cabor(list_cabor lc);
adr_cabor findelemcabor(list_cabor lc, string x);

void createlist_relasi(list_relasi &lr);
void createelm_relasi(adr_relasi &r, adr_cabor c, adr_negara n);
bool isRelasiEmpty(list_relasi lr);
void insert_relasi(list_relasi &lr, adr_relasi r);
void show_relasi(list_relasi lr);
adr_relasi findelemrelasi(list_relasi lr, adr_cabor c, adr_negara n);

void findnegarafromcabor(list_relasi lr, string x);
void showallnegarafromallcabor(list_cabor lc, list_relasi lr);
int getsumnegarafromcabor(list_relasi lr, string x);
void findminmax(list_relasi lr, list_cabor lc);
adr_cabor findcaborfromnegara(list_relasi lr, string x);

void delete_cabor(list_cabor &lc, list_relasi &lr, string x);
void delete_negarafromcabor(list_relasi &lr, string x);

int menu();

#endif // OLIMPIADE_H_INCLUDED
